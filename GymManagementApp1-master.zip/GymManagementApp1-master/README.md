# GymManagementApp1
Gym Management Application with :
-> ASP.NET CORE 3.1 MVC | C#
-> Entity Framework Core 3.1.4 | Migrations
-> Sql Server 2019
-> Bootstrap 4
-> JQuery DataTables
-> Toastr Notifications
-> AJAX
